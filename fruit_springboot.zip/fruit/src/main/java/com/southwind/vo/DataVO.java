package com.southwind.vo;

import lombok.Data;

import java.util.Map;

@Data
public class DataVO {
    private Integer value;
    private Map<String,String> itemStyle;
}
